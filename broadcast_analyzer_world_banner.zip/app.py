
from flask import Flask, render_template, request, redirect, url_for, session, send_file
import subprocess, os

app = Flask(__name__)
app.secret_key = 'kader11000'

PASSWORD = "kader11000"

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['password'] == PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('analyze'))
    return render_template('login.html')

@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    result = None
    link = ""
    if request.method == 'POST':
        link = request.form['stream_url']
        protocol = "HTTPS" if link.startswith("https://") else "HTTP"
        has_token = "Yes" if "token=" in link.lower() else "No"

        try:
            cmd = ['ffprobe', '-v', 'error', '-show_format', '-show_streams', link]
            ffprobe_output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=10).decode()
        except subprocess.CalledProcessError as e:
            ffprobe_output = f"Error: {e.output.decode()}"
        except subprocess.TimeoutExpired:
            ffprobe_output = "Error: Timed out."

        result = {
            'protocol': protocol,
            'token': has_token,
            'ffprobe': ffprobe_output
        }
    return render_template('analyze.html', result=result, link=link)

@app.route('/record', methods=['POST'])
def record():
    url = request.form['stream_url']
    output_file = "recorded.ts"
    try:
        subprocess.run(['ffmpeg', '-i', url, '-t', '10', '-c', 'copy', output_file], timeout=15)
        return send_file(output_file, as_attachment=True)
    except Exception as e:
        return f"Error: {e}"

if __name__ == '__main__':
    app.run(debug=True)
